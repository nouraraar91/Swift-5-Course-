import UIKit

var str = "Hello, playground"

// var name:Type = value    // how we can define var in swift

var firstName = "Nour"

// var types
// numbers : Int , Double, Float

var numb1: Int = 10
print(numb1)
var age: Int = 30

var numb2: Double = 10
var price: Double = 250.80
var numb3 = 11

// strings

var name: String = "Nour"

name = "Araar"


var lastName: String

lastName = "Araar"


// bool
var isOK: Bool = true

print(isOK)
