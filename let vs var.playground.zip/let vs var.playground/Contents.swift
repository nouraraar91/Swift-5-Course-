import UIKit

var str = "Hello, playground"


// let name: Type = value // define constants in Swift

let pi = 3.14
let e = 2.7

var x = 10

let name: String = "Nour"

let firstName: String = "Nour"


